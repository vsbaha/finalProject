// src/App.jsx
import Product from "./Product";
import "./App.css";

const App = () => {
  return (
    <div className="app">
      <Product />
    </div>
  );
};

export default App;
